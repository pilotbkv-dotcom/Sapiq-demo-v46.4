# Sapiq demo v46.4 — website, terminal, PWA

This is a static GitHub Pages DEMO, not a live trading system. No real bookmaker bets or Polymarket orders, payments, wallet authorization or extension installation occur here.

## Pages
- Main (Russian): `/index.html` and `/ru/index.html`
- EN/ES/ZH: `/en/`, `/es/`, `/zh/`
- RU terminal: `/ru/terminal/index.html`
- EN/ES/ZH terminal: `/terminal/index.html`, `/es/terminal/index.html`, `/zh/terminal/index.html`
- Mobile PWA: `/pwa/index.html`

## Deploy (browser-only GitHub Pages Actions)
Use the `Sapiq-v46.4-GITHUB-2-FILES-KIT.zip` bundle and upload its `site.zip` to repository root. Set repository `Settings → Pages → Source: GitHub Actions`. Create or replace `.github/workflows/pages.yml` from the kit's `pages.yml`. Commit to `main`, then check Actions. Do NOT upload the outer kit ZIP as the site payload. The action unpacks `site.zip` and verifies the required routes and resources.

## Demo login
On the landing press Sign in. Use the *Fill demo credentials* button in the sign-in dialog. The local demo gate is not security/authentication for real funds.

## PnL exports
Only after BOTH simulated legs are confirmed; 16:9, 1:1 and 9:16. Exports and previews call the same canvas renderer. The branded QR resolves to `https://sapiq.io/`. Data is estimated/illustrative and excludes commissions, slippage and settlement-rule risk. The landing gallery is produced from the same renderer and labelled as examples, not actual profits.

## Files
This archive includes v46.4 acceptance notes. `README-v46.3.md` is preserved as historical information and is superseded by this file. The demo's original logos, mascot art and prior routes are retained.

## Known limits
Tests ran locally in Chromium with controlled static asset routing; the test harness alone used storage shims because localhost navigation was blocked in this environment. HTTPS GitHub Pages, Safari, physical Android/iPhone and standalone installed PWA were not exercised. Native speakers have not reviewed every legacy article in all locales. Backend integrations are simulated only.
