# Sapiq v46.3 - release summary

This package is a static offline demonstration for GitHub Pages; it is not a live trading or payment integration.

- Corrected Russian greeting on the root landing and streamlined mascot title on RU, EN, ES and ZH.
- Reworked card generation in 16:9, 1:1 and 9:16: prominent ROI and amount, matching venue details, Sapiq mascot, Polymarket Verified Builder and QR to sapiq.io. The on-screen preview and downloaded PNG use the same canvas renderer.
- Four language-specific landing gallery collages are built from the exact same PnL renderer, eliminating mismatched promo graphics.
- Enlarged desktop preview; added user-controlled zoom on mobile.
- Localized primary terminal sidebar and split/sort controls that were left in English on RU, ES, ZH.
- Updated PWA service worker cache version.

DEMO CAVEAT: Prices, stakes, wallet state and transactions are illustrations. No real orders or payments are sent. QR points to https://sapiq.io/.

Deploy using the separate 2-file GitHub kit (site.zip + pages.yml) and GitHub Pages Actions. Test the live URL and an installed mobile PWA after publishing.
