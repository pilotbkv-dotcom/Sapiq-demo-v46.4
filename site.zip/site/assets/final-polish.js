/* Sapiq v46.2 — low-cost progressive enhancement; no network calls. */
(()=>{'use strict';
const lang=(document.documentElement.lang||'en').slice(0,2);const L={
ru:{price:'Цена доли Polymarket',shares:'Долей к покупке',buy:'Сумма покупки Polymarket',book:'Ставка у букмекера',total:'Общая сумма',payout:'Выплата при любом исходе',profit:'Разница до комиссий',invalid:'Проверьте введённые значения',odds:'Коэффициент',live:'Проверить параметры в терминале'},
en:{price:'Polymarket share price',shares:'Shares to buy',buy:'Polymarket purchase',book:'Sportsbook stake',total:'Total stake',payout:'Payout for either outcome',profit:'Difference before fees',invalid:'Check the values entered',odds:'Odds',live:'Check the workflow in the terminal'},
es:{price:'Precio por participación',shares:'Participaciones a comprar',buy:'Compra en Polymarket',book:'Apuesta en la casa',total:'Importe total',payout:'Pago para cualquiera de los resultados',profit:'Diferencia antes de comisiones',invalid:'Comprueba los valores',odds:'Cuota',live:'Consulta los pasos en el terminal'},
zh:{price:'Polymarket 每份价格',shares:'需购买份额',buy:'Polymarket 买入金额',book:'博彩公司下注金额',total:'总投入',payout:'任一结果的预期返还',profit:'手续费前差额',invalid:'请检查输入数值',odds:'赔率',live:'在终端查看完整流程'} }[lang]||{};
const $=q=>document.querySelector(q);const safe=n=>Number.isFinite(n)?n.toLocaleString(lang==='ru'?'ru-RU':lang==='es'?'es-ES':lang==='zh'?'zh-CN':'en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
/* Workbench math: bookmaker stake B at odds o, opposite Polymarket shares n=B*o, price p in USD. */
function detail(){const a=$('#r15-odd'),b=$('#r15-poly'),c=$('#r15-budget'),out=$('#r15-div');if(!a||!b||!c||!out)return;let o=Number(a.value),pc=Number(b.value),B=Number(c.value);const valid=Number.isFinite(o)&&o>1&&o<=1000&&Number.isFinite(pc)&&pc>0&&pc<100&&Number.isFinite(B)&&B>0&&B<=1e7;if(!valid){out.textContent=L.invalid;return}
const p=pc/100,n=B*o,poly=n*p,total=B+poly,gross=n-total;
const rows=[[L.price,`${safe(pc)}¢  ($${safe(p)})`],[L.shares,safe(n)],[L.buy,`$${safe(poly)}`],[L.book,`$${safe(B)}  × ${safe(o)}`],[L.total,`$${safe(total)}`],[L.profit,`${gross>=0?'+':'−'}$${safe(Math.abs(gross))}`]];
const wrap=document.createElement('div');wrap.className='v47-breakdown';rows.forEach(([label,val],i)=>{const item=document.createElement('div');if(i===1||i===2)item.className='v47-highlight';const span=document.createElement('span');const strong=document.createElement('strong');span.textContent=label;strong.textContent=val;item.append(span,strong);wrap.append(item)});out.replaceChildren(wrap);
}
const fields=['#r15-odd','#r15-poly','#r15-budget'].map($).filter(Boolean);
if(fields.length===3){fields.forEach(el=>el.addEventListener('input',()=>queueMicrotask(detail)));queueMicrotask(detail)}
/* The hero shows the actual terminal; full three-format PnL gallery appears further down. */
const overlapping=$('.r15-art.v46-art .v46-hero-cards');if(overlapping){overlapping.remove();$('.r15-art.v46-art .v46-hero-legend')?.remove()}
/* Rebuild brand social icons with aligned boxes and proper optical weight. */
for(const a of document.querySelectorAll('a.v46-social')){const href=a.href.toLowerCase();let svg;
if(href.includes('t.me'))svg='<svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M21.5 3.1a1.4 1.4 0 0 0-1.46-.17L2.5 9.7c-1.12.45-1.1 1.13-.19 1.41l4.7 1.47 1.82 5.56c.19.57.32.79.65.79.23 0 .43-.1.66-.33l2.55-2.44 4.76 3.52c.88.49 1.5.24 1.73-.82L22 4.6c.27-1.15-.17-1.51-.5-1.5ZM8.6 12.22l10.3-6.55c.48-.3.92-.14.56.2l-8.46 7.65-.33 3.47-2.07-4.77Z"/></svg>';
else if(href.includes('x.com'))svg='<svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M17.35 2h3.3l-7.2 8.25L22 22h-6.65l-5.2-6.92L4.1 22H.75l7.71-8.87L1.1 2h6.83l4.72 6.28L17.35 2Zm-1.16 18h1.84L6.91 3.88H5.03L16.19 20Z"/></svg>';
else if(href.includes('instagram'))svg='<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="2.5" y="2.5" width="19" height="19" rx="5.4"/><circle cx="12" cy="12" r="4.25"/><circle cx="17.6" cy="6.5" r="1.1" fill="currentColor" stroke="none"/></svg>';
if(svg){const old=a.querySelector('svg');if(old)old.outerHTML=svg}}
})();
