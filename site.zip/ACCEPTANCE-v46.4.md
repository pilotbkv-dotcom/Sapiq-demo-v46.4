# Sapiq v46.4 — acceptance evidence

## Baseline and approved visual reference
- Frozen source: `Sapiq-demo-v46.3-WEBSITE-AND-PWA.zip`; SHA-256 `3232085b840da843438c8fa3fd0d20b5d34715b4456675ad91ca5bd236f317ec`.
- PnL composition reference: user-supplied three-card picture `image(20261109-221330).png` (two cards behind a wide front card).
- Priority: explicit recent requirements, supplied brand art, then unchanged v46.3 UI and behavior. No new integrations or UX features were added.

## Acceptance matrix

| Requirement | Screen / component | Expected | Evidence |
|---|---|---|---|
| Correct original brand art | all landing locales / PnL canvas | original logo and blue Sapiq mascot | SHA-256 asset equality vs frozen v46.3 |
| Reference-oriented PnL | gallery and downloaded PNG | 3-format composition, large ROI, mascot, two legs, muted Verified Builder, QR | same renderer in all locales; gallery exports regenerated from it; manually inspected PNG |
| Card correctness | terminal PnL | available after both legs; fixed executed data; no guaranteed profit | automated two-leg flow, data stable after quote change |
| QR works | three PNG dimensions | scans to `https://sapiq.io/` | decoded exported PNG with OpenCV |
| Demo gate | landing and terminal | sign-in accessible, invalid credentials rejected, close/reopen/keyboard | Chromium UI actions; isolated storage shim in test environment |
| Both hedge orders | terminal calculator | simulated legs and limit pending remain distinct | Chromium UI scenario for Polymarket-first/bookmaker-first |
| Heatmap | schedule | time/event schedule, not a guaranteed profit forecast | schedule smoke test and rendered copy review |
| PWA | 360/390/768 | mobile cards, bottom navigation, calculator opens | Chromium click tests; breakpoint-dependent selectors |
| Localization | RU/EN/ES/ZH | headings, assistant and PnL labels in selected language | browser checks and file-level review; **not native speaker certified** |
| Adaptivity | 360×800, 390×844, 768×1024, 1366×768, 1440×900, 895×850 | no unintended body horizontal overflow | Chromium viewport simulation, not physical phones |
| GitHub pages file paths | complete HTML set | local assets and routes resolve | static scan of all HTML local href/src values |

## Verified modifications
- Replaced only the PnL canvas composition code in `site/assets/v46_terminal.js`, preserving both deal legs, math, original mascot/logo and same PNG/preview renderer.
- Rendered four localized 3-format gallery composites (`site/assets/pnl-trio-v464-{ru,en,es,zh}.webp`) using that same canvas.
- Updated 5 landing HTML gallery references, the PWA service-worker revision and current README.
- Fixed wide 16:9 footer text rendering and spacing to avoid overlap with QR or event/leg blocks.
- Changed sample-only footer to say the legs are not executed; confirmed demo result displays a different status.

## Checks performed
- `static`: 39/39 selected assertions passed.
- `browser-locales`: 123/123 selected assertions passed.
- `browser-trade`: 23/23 selected assertions passed.
- `browser-inverse-pwa`: 19/19 selected assertions passed.
- `helper`: 20/20 selected assertions passed.
- Static verification included **2,004 local HTML URL references** across the packaged HTML pages, JS syntax checks and approved-image byte comparisons.
- Controlled Chromium test uses Playwright `route.fulfill` for local assets. Since browser policy denies real navigation to localhost or synthetic domains, test pages are inserted with `set_content`; only the **test harness** adds an in-memory `sessionStorage`/`localStorage` shim. This is not an HTTPS end-to-end test.
- QR scan checked from the actual exported PNGs, not just the source PNG asset.

## Not verified / release conditions
- No physical iOS Safari, Android Chrome or installed standalone PWA test; no live GitHub Pages deploy tested in this session.
- Backend execution, bookmaker deep links, Polymarket liquidity, payments and wallets are still simulated.
- Full professional native-language editorial review of every legacy long-form page was not available. Main landing, helper, calculator labels and PnL were checked locally.
- No independent Gemini inspection was performed: no available tool can access an authenticated Gemini session. A manual review packet is supplied separately, but **nothing was transmitted externally**.
- Conversion impact remains unproven; requires real analytics/A/B experimentation.

No reproduced unresolved P0/P1 was identified in the scenarios actually exercised. This does not prove that every scenario or device is defect-free. Deploy as a DEMO and check its public HTTPS address before presenting to external partners.
